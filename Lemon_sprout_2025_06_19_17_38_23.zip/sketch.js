function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}let flores = [];
let borboletas = [];
let abelhas = [];

const NUM_FLORES = 5;
const NUM_BORBOLETAS = 5;
const NUM_ABELHAS = 3;

function setup() {
  createCanvas(800, 600);
  
  // Criar flores
  for (let i = 0; i < NUM_FLORES; i++) {
    // Garantir que as flores fiquem na parte da grama
    let x = random(width * 0.1, width * 0.9);
    let y = random(height - 130, height - 30); // Acima da grama
    flores.push(new Flor(x, y, random(15, 30)));
  }

  // Criar borboletas
  for (let i = 0; i < NUM_BORBOLETAS; i++) {
    borboletas.push(new Borboleta(random(width), random(height * 0.2, height * 0.7))); // Voam mais alto
  }

  // Criar abelhas
  for (let i = 0; i < NUM_ABELHAS; i++) {
    abelhas.push(new Abelha(random(width), random(height * 0.2, height * 0.7)));
  }
}

function draw() {
  // Céu
  background(135, 206, 235);
  
  // Sol
  fill(255, 255, 0);
  noStroke();
  ellipse(width - 100, 100, 80, 80);
  
  // Grama
  fill(34, 139, 34);
  rect(0, height - 150, width, 150);
  
  // Desenhar e atualizar flores
  for (let flor of flores) {
    flor.display();
  }

  // Desenhar e atualizar borboletas
  for (let borboleta of borboletas) {
    borboleta.update();
    borboleta.display();
  }

  // Desenhar e atualizar abelhas
  for (let abelha of abelhas) {
    abelha.update();
    abelha.display();
  }
}

// --- CLASSE FLOR ---
class Flor {
  constructor(x, y, tamanho) {
    this.x = x;
    this.y = y;
    this.tamanho = tamanho;
    this.corCaule = color(0, 100, 0);
    this.corCentro = color(255, 165, 0);
    this.corPetalas = color(random(150, 255), random(150, 255), random(150, 255));
  }

  display() {
    push();
    translate(this.x, this.y);

    // Caule
    fill(this.corCaule);
    rect(-2, -this.tamanho * 2, 4, this.tamanho * 2); 
    
    // Pétalas
    fill(this.corPetalas);
    ellipse(0, -this.tamanho * 2 - 10, this.tamanho, this.tamanho);
    ellipse(this.tamanho * 0.7, -this.tamanho * 2 - 5, this.tamanho, this.tamanho);
    ellipse(-this.tamanho * 0.7, -this.tamanho * 2 - 5, this.tamanho, this.tamanho);
    ellipse(0, -this.tamanho * 2 + 10, this.tamanho, this.tamanho);
    ellipse(this.tamanho * 0.7, -this.tamanho * 2 + 5, this.tamanho, this.tamanho);
    ellipse(-this.tamanho * 0.7, -this.tamanho * 2 + 5, this.tamanho, this.tamanho);
    
    // Centro da flor
    fill(this.corCentro);
    ellipse(0, -this.tamanho * 2, this.tamanho * 0.5, this.tamanho * 0.5);

    pop();
  }
}

// --- CLASSE BORBOLETA ---
class Borboleta {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.targetX = x; // Onde a borboleta quer ir
    this.targetY = y;
    this.velocidade = random(0.8, 1.5);
    this.tamanhoAsa = random(20, 35);
    this.corAsa1 = color(random(150, 255), random(100, 200), random(100, 255), 200); // Cor com transparência
    this.corAsa2 = color(random(100, 255), random(150, 200), random(100, 255), 200);
    this.faseAsa = random(TWO_PI);
    this.velocidadeFase = random(0.1, 0.3);
    this.estado = 'voando'; // 'voando' ou 'pousado'
    this.florAlvo = null; // A flor em que está pousada
    this.tempoPousado = 0;
    this.maxTempoPousado = random(180, 480); // Tempo em frames para ficar pousado (3 a 8 segundos)
  }

  update() {
    if (this.estado === 'voando') {
      // Movimento errático + movimento em direção a um alvo aleatório
      this.x += (this.targetX - this.x) * 0.01 + random(-0.5, 0.5);
      this.y += (this.targetY - this.y) * 0.01 + random(-0.5, 0.5);

      // Define um novo alvo se chegou perto do atual
      if (dist(this.x, this.y, this.targetX, this.targetY) < 20 || frameCount % 120 === 0) {
        this.targetX = random(width);
        this.targetY = random(height * 0.2, height * 0.7); // Mantém voando mais alto
      }

      // Tenta pousar em uma flor
      if (random(1) < 0.01 && flores.length > 0) { // Pequena chance de tentar pousar
        let florProxima = this.encontrarFlorProxima();
        if (florProxima && dist(this.x, this.y, florProxima.x, florProxima.y - florProxima.tamanho * 2) < 100) {
          this.x = florProxima.x + random(-5, 5); // Pousa ligeiramente aleatório na flor
          this.y = florProxima.y - florProxima.tamanho * 2 + random(-5, 5); // No centro da flor
          this.estado = 'pousado';
          this.florAlvo = florProxima;
          this.tempoPousado = 0;
          this.velocidadeFase = 0.05; // Asas batem mais lento quando pousado
        }
      }
      
    } else if (this.estado === 'pousado') {
      this.tempoPousado++;
      if (this.tempoPousado > this.maxTempoPousado) {
        this.estado = 'voando';
        this.florAlvo = null;
        this.velocidadeFase = random(0.1, 0.3); // Voltar à velocidade normal
        // Define um alvo para longe da flor atual
        this.targetX = random(width);
        this.targetY = random(height * 0.2, height * 0.7);
      }
    }

    // Mantém a borboleta na tela se ela sair muito
    this.x = constrain(this.x, -50, width + 50);
    this.y = constrain(this.y, -50, height + 50);

    this.faseAsa += this.velocidadeFase;
  }

  display() {
    push();
    translate(this.x, this.y);

    let anguloAsa = sin(this.faseAsa) * PI / 8; // Menor amplitude ao bater
    if (this.estado === 'pousado') {
      anguloAsa = sin(this.faseAsa) * PI / 16; // Asas quase paradas
    }

    noStroke();

    // Asa esquerda superior
    fill(this.corAsa1);
    ellipse(-this.tamanhoAsa * 0.7, -this.tamanhoAsa * 0.5, this.tamanhoAsa * 1.5, this.tamanhoAsa);

    // Asa direita superior
    push();
    rotate(anguloAsa);
    fill(this.corAsa2);
    ellipse(this.tamanhoAsa * 0.7, -this.tamanhoAsa * 0.5, this.tamanhoAsa * 1.5, this.tamanhoAsa);
    pop();

    // Corpo
    fill(50, 50, 50);
    ellipse(0, 0, this.tamanhoAsa * 0.4, this.tamanhoAsa * 1.2);

    pop();
  }

  encontrarFlorProxima() {
    let florMaisProxima = null;
    let menorDistancia = Infinity;

    for (let flor of flores) {
      // Calcula a distância até o centro da flor
      let d = dist(this.x, this.y, flor.x, flor.y - flor.tamanho * 2);
      if (d < menorDistancia) {
        menorDistancia = d;
        florMaisProxima = flor;
      }
    }
    return florMaisProxima;
  }
}

// --- CLASSE ABELHA ---
class Abelha {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.targetX = x;
    this.targetY = y;
    this.velocidade = random(1, 2);
    this.tamanho = random(10, 15);
    this.faseAsa = random(TWO_PI);
    this.velocidadeFase = random(0.5, 0.8); // Asas batem muito rápido
    this.estado = 'voando';
    this.florAlvo = null;
    this.tempoPousado = 0;
    this.maxTempoPousado = random(60, 240); // Tempo em frames (1 a 4 segundos)
  }

  update() {
    if (this.estado === 'voando') {
      // Movimento em direção ao alvo, com um pouco de aleatoriedade
      this.x = lerp(this.x, this.targetX, 0.05) + random(-0.2, 0.2);
      this.y = lerp(this.y, this.targetY, 0.05) + random(-0.2, 0.2);

      // Se perto do alvo ou a cada X frames, encontra um novo alvo
      if (dist(this.x, this.y, this.targetX, this.targetY) < 10 || frameCount % 60 === 0) {
        // Alvo preferencialmente em direção às flores
        let florProxima = this.encontrarFlorProxima();
        if (florProxima) {
          this.targetX = florProxima.x + random(-10, 10);
          this.targetY = florProxima.y - florProxima.tamanho * 2 + random(-10, 10);
        } else {
          this.targetX = random(width);
          this.targetY = random(height * 0.2, height * 0.7);
        }
      }

      // Tenta pousar em uma flor
      if (random(1) < 0.02 && flores.length > 0) { // Maior chance de pousar que a borboleta
        let florProxima = this.encontrarFlorProxima();
        if (florProxima && dist(this.x, this.y, florProxima.x, florProxima.y - florProxima.tamanho * 2) < 50) {
          this.x = florProxima.x + random(-5, 5); // Pousa ligeiramente aleatório na flor
          this.y = florProxima.y - florProxima.tamanho * 2 + random(-5, 5); // No centro da flor
          this.estado = 'pousado';
          this.florAlvo = florProxima;
          this.tempoPousado = 0;
          this.velocidadeFase = 0.0; // Asas param de bater
        }
      }

    } else if (this.estado === 'pousado') {
      this.tempoPousado++;
      if (this.tempoPousado > this.maxTempoPousado) {
        this.estado = 'voando';
        this.florAlvo = null;
        this.velocidadeFase = random(0.5, 0.8); // Voltar à velocidade normal
        // Define um alvo para longe da flor atual
        this.targetX = random(width);
        this.targetY = random(height * 0.2, height * 0.7);
      }
    }
    
    // Mantém a abelha na tela se ela sair muito
    this.x = constrain(this.x, -50, width + 50);
    this.y = constrain(this.y, -50, height + 50);

    this.faseAsa += this.velocidadeFase;
  }

  display() {
    push();
    translate(this.x, this.y);

    // Corpo
    fill(255, 200, 0); // Amarelo
    ellipse(0, 0, this.tamanho, this.tamanho * 1.2); // Corpo principal
    fill(0); // Preto
    ellipse(0, -this.tamanho * 0.3, this.tamanho * 0.8, this.tamanho * 0.8); // Faixa preta superior
    ellipse(0, this.tamanho * 0.3, this.tamanho * 0.8, this.tamanho * 0.8); // Faixa preta inferior

    // Asas
    fill(200, 200, 255, 150); // Azul claro com transparência
    noStroke();
    if (this.estado === 'voando') {
      // Simula o bater de asas muito rápido, quase um borrão
      ellipse(-this.tamanho * 0.5, -this.tamanho * 0.8, this.tamanho * 0.8, this.tamanho * 0.3 + sin(this.faseAsa) * 5); // Asa esquerda
      ellipse(this.tamanho * 0.5, -this.tamanho * 0.8, this.tamanho * 0.8, this.tamanho * 0.3 + sin(this.faseAsa) * 5); // Asa direita
    } else { // Pousado
        ellipse(-this.tamanho * 0.5, -this.tamanho * 0.8, this.tamanho * 0.8, this.tamanho * 0.3); // Asa esquerda
        ellipse(this.tamanho * 0.5, -this.tamanho * 0.8, this.tamanho * 0.8, this.tamanho * 0.3); // Asa direita
    }

    // Antenas
    stroke(0);
    strokeWeight(1);
    line(0, -this.tamanho * 0.6, -this.tamanho * 0.4, -this.tamanho * 1);
    line(0, -this.tamanho * 0.6, this.tamanho * 0.4, -this.tamanho * 1);
    
    pop();
  }

  encontrarFlorProxima() {
    let florMaisProxima = null;
    let menorDistancia = Infinity;

    for (let flor of flores) {
      // Calcula a distância até o centro da flor
      let d = dist(this.x, this.y, flor.x, flor.y - flor.tamanho * 2);
      if (d < menorDistancia) {
        menorDistancia = d;
        florMaisProxima = flor;
      }
    }
    return florMaisProxima;
  }
}
